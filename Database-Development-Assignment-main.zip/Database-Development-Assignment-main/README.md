# Database-Development-Assignment
Me and my other 4 member created a database for a Hotel to store numerous data, and i am responsible in making the diagram, country table,  department table, as well as 3 other reports written in the documentation
